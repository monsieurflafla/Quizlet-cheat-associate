// ─── État ────────────────────────────────────────────────────
let currentWords = {};
let activeSetId = null;

// ─── Init ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadWordsFromStorage();
  await renderSets();
  renderWords();
  checkPage();

  // Tabs
  document.querySelectorAll('.tab').forEach(t => {
    t.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(x => x.classList.remove('active'));
      t.classList.add('active');
      document.getElementById('tab-' + t.dataset.tab).classList.add('active');
    });
  });

  document.getElementById('btnScrape').addEventListener('click', scrapeAndMerge);
  document.getElementById('btnScrapeWords').addEventListener('click', scrapeAndMerge);
  document.getElementById('btnRun').addEventListener('click', runBot);
  document.getElementById('btnAddWord').addEventListener('click', addWordManually);
  document.getElementById('btnClearWords').addEventListener('click', clearWords);
  document.getElementById('btnSaveSet').addEventListener('click', saveSet);

  // Speed slider
  const SPEED_PRESETS = [
    { label: '0ms — Turbo', move: 5,  hover: 10,  hold: 20,  between: 45,   pair: 68   },
    { label: 'Rapide',           move: 5,  hover: 10, hold: 20, between: 50,  pair: 80  },
    { label: 'Normal',           move: 15, hover: 40, hold: 60, between: 200, pair: 300 },
    { label: 'Humain',           move: 20, hover: 60, hold: 100,between: 350, pair: 500 },
    { label: 'Lent',             move: 25, hover: 90, hold: 150,between: 500, pair: 800 },
  ];
  window.SPEED_PRESETS = SPEED_PRESETS;
  const slider = document.getElementById('speedSlider');
  const speedLabel = document.getElementById('speedLabel');
  const updateLabel = () => { speedLabel.textContent = SPEED_PRESETS[+slider.value].label; };
  slider.addEventListener('input', updateLabel);
  updateLabel();

  // Latency slider
  const latencySlider = document.getElementById('latencySlider');
  const latencyLabel = document.getElementById('latencyLabel');
  const updateLatency = () => { latencyLabel.textContent = latencySlider.value + 'ms'; };
  latencySlider.addEventListener('input', updateLatency);
  updateLatency();

  // Enter on inputs
  [document.getElementById('inputTerm'), document.getElementById('inputDef')].forEach(inp => {
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') addWordManually(); });
  });

  // Écoute les messages du content script
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'botStatus') updateBotStatus(msg);
  });
});

// ─── Storage ─────────────────────────────────────────────────
async function loadWordsFromStorage() {
  return new Promise(res => {
    chrome.storage.local.get(['currentWords', 'activeSetId'], data => {
      currentWords = data.currentWords || {};
      activeSetId = data.activeSetId || null;
      res();
    });
  });
}

async function saveWordsToStorage() {
  return new Promise(res => {
    chrome.storage.local.set({ currentWords, activeSetId }, res);
  });
}

async function getSets() {
  return new Promise(res => {
    chrome.storage.local.get(['sets'], data => res(data.sets || {}));
  });
}

async function saveSets(sets) {
  return new Promise(res => chrome.storage.local.set({ sets }, res));
}

// ─── Page check ──────────────────────────────────────────────
async function checkPage() {
  const badge = document.getElementById('pageBadge');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes('quizlet.com')) {
      badge.textContent = '✓ Quizlet';
      badge.className = 'badge ok';
    } else {
      badge.textContent = '✗ Pas Quizlet';
      badge.className = 'badge err';
    }
  } catch(e) {
    badge.textContent = '?';
  }
}

// ─── Scrape ──────────────────────────────────────────────────
async function scrapeAndMerge() {
  setStatus('running', 'Détection des mots…');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const result = await chrome.tabs.sendMessage(tab.id, { action: 'scrapeWords' });
    const found = result && result.words ? result.words : {};
    const count = Object.keys(found).length;
    if (count === 0) {
      setStatus('error', 'Aucun mot trouvé sur cette page.');
      return;
    }
    Object.assign(currentWords, found);
    await saveWordsToStorage();
    renderWords();
    setStatus('success', `${count} mots détectés et ajoutés !`);
  } catch (e) {
    setStatus('error', 'Impossible de lire la page. Recharge la page.');
  }
}

// ─── Bot ─────────────────────────────────────────────────────
async function runBot() {
  const count = Object.keys(currentWords).length;
  if (count === 0) {
    setStatus('error', 'Aucun mot chargé. Détecte d\'abord les mots.');
    return;
  }
  setStatus('running', `Lancement du bot (${count} mots)…`);
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const speed = window.SPEED_PRESETS[+(document.getElementById('speedSlider').value)];
    const loadDelay = +(document.getElementById('latencySlider').value);
    await chrome.tabs.sendMessage(tab.id, { action: 'runBot', words: currentWords, speed, loadDelay });
  } catch (e) {
    setStatus('error', 'Erreur. Recharge la page et réessaie.');
  }
}

function updateBotStatus(msg) {
  if (msg.status === 'running') setStatus('running', 'Bot en cours…');
  else if (msg.status === 'done') setStatus('success', `✓ Bot terminé — ${msg.matched || '?'} paires associées !`);
  else if (msg.status === 'error') setStatus('error', 'Erreur : ' + (msg.error || ''));
}

// ─── Status bar ──────────────────────────────────────────────
function setStatus(type, text) {
  const bar = document.getElementById('statusBar');
  const txt = document.getElementById('statusText');
  bar.className = 'status-bar ' + type;
  txt.textContent = text;
}

// ─── Words UI ────────────────────────────────────────────────
function renderWords() {
  const list = document.getElementById('wordList');
  const count = Object.keys(currentWords).length;
  document.getElementById('wordCount').textContent = count;

  if (count === 0) {
    list.innerHTML = '<div class="empty-msg">Aucun mot. Utilise "Détecter" ou ajoute manuellement.</div>';
    return;
  }

  list.innerHTML = Object.entries(currentWords).map(([k, v]) => `
    <div class="word-item">
      <span class="term">${esc(k)}</span>
      <span class="arrow">→</span>
      <span class="def">${esc(v)}</span>
      <button class="del-btn" data-key="${esc(k)}">×</button>
    </div>
  `).join('');

  list.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      delete currentWords[btn.dataset.key];
      await saveWordsToStorage();
      renderWords();
    });
  });
}

function addWordManually() {
  const t = document.getElementById('inputTerm').value.trim();
  const d = document.getElementById('inputDef').value.trim();
  if (!t || !d) return;
  currentWords[t] = d;
  saveWordsToStorage().then(renderWords);
  document.getElementById('inputTerm').value = '';
  document.getElementById('inputDef').value = '';
  document.getElementById('inputTerm').focus();
}

async function clearWords() {
  if (!confirm('Vider tous les mots ?')) return;
  currentWords = {};
  await saveWordsToStorage();
  renderWords();
  setStatus('', 'Liste vidée.');
}

// ─── Sets ────────────────────────────────────────────────────
async function saveSet() {
  const count = Object.keys(currentWords).length;
  if (count === 0) { setStatus('error', 'Aucun mot à sauvegarder.'); return; }

  const name = prompt(`Nom du set (${count} mots) :`, 'Set ' + new Date().toLocaleDateString('fr'));
  if (!name) return;

  const sets = await getSets();
  const id = Date.now().toString();
  sets[id] = { name, words: { ...currentWords }, createdAt: Date.now() };
  await saveSets(sets);
  await renderSets();
  setStatus('success', `Set "${name}" sauvegardé !`);
}

async function renderSets() {
  const sets = await getSets();
  const container = document.getElementById('setsList');
  const ids = Object.keys(sets);

  if (ids.length === 0) {
    container.innerHTML = '<div class="empty-msg">Aucun set sauvegardé.</div>';
    return;
  }

  container.innerHTML = ids.sort((a, b) => sets[b].createdAt - sets[a].createdAt).map(id => `
    <div class="set-item ${activeSetId === id ? 'active' : ''}" data-id="${id}">
      <div class="set-info">
        <div class="set-name">${esc(sets[id].name)}</div>
        <div class="set-meta">${Object.keys(sets[id].words).length} mots · ${new Date(sets[id].createdAt).toLocaleDateString('fr')}</div>
      </div>
      <button class="set-del" data-id="${id}" title="Supprimer">🗑</button>
    </div>
  `).join('');

  // Charger un set en cliquant dessus
  container.querySelectorAll('.set-item').forEach(el => {
    el.addEventListener('click', async (e) => {
      if (e.target.classList.contains('set-del')) return;
      const id = el.dataset.id;
      const sets = await getSets();
      if (!sets[id]) return;
      currentWords = { ...sets[id].words };
      activeSetId = id;
      await saveWordsToStorage();
      renderWords();
      await renderSets();
      setStatus('success', `Set "${sets[id].name}" chargé (${Object.keys(currentWords).length} mots).`);
      // Switch to words tab
      document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(x => x.classList.remove('active'));
      document.querySelector('[data-tab="play"]').classList.add('active');
      document.getElementById('tab-play').classList.add('active');
    });
  });

  // Supprimer un set
  container.querySelectorAll('.set-del').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const sets = await getSets();
      if (!confirm(`Supprimer "${sets[id]?.name}" ?`)) return;
      delete sets[id];
      await saveSets(sets);
      if (activeSetId === id) { activeSetId = null; await saveWordsToStorage(); }
      await renderSets();
    });
  });
}

// ─── Utils ───────────────────────────────────────────────────
const esc = s => (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
