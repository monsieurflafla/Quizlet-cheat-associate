// content.js — injecté sur toutes les pages quizlet.com

// Écoute les messages du popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'scrapeWords') {
    const words = scrapeCurrentPage();
    sendResponse({ words });
  } else if (msg.action === 'runBot') {
    runMatchBot(msg.words, msg.speed, msg.loadDelay);
    sendResponse({ ok: true });
  } else if (msg.action === 'ping') {
    sendResponse({ ok: true });
  }
  return true; // async
});

function scrapeCurrentPage() {
  const dict = {};

  // ── Méthode 1 : structure exacte Quizlet 2025 ────────────────
  // Chaque carte = div[aria-label="Terme"][class*="SetPageTermsList-term"]
  // À l'intérieur : deux blocs de texte (terme + définition)
  // On extrait le texte des deux premiers noeuds textuels feuilles

  const getLeafText = (el) => {
    // Récupère le texte du premier noeud "feuille" non-vide
    // (ignore les boutons, icônes, spans audio etc.)
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, {
      acceptNode: n => n.textContent.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
    });
    const texts = [];
    let node;
    while ((node = walker.nextNode())) {
      const t = node.textContent.trim();
      // Ignorer les textes parasites courts (numéros, icônes)
      if (t && t.length > 1) texts.push(t);
    }
    return texts;
  };

  const cards = document.querySelectorAll('[aria-label="Terme"][class*="SetPageTermsList-term"]');
  if (cards.length > 0) {
    cards.forEach(card => {
      // Structure exacte : deux span.TermText par carte (terme + définition)
      const spans = card.querySelectorAll('span.TermText');
      if (spans.length >= 2) {
        const term = spans[0].textContent.trim();
        const def  = spans[1].textContent.trim();
        if (term && def && term !== def) dict[term] = def;
      }
    });
  }

  // ── Méthode 2 : __NEXT_DATA__ JSON (fallback fiable) ─────────
  if (Object.keys(dict).length === 0) {
    try {
      const nextData = document.getElementById('__NEXT_DATA__');
      if (nextData) {
        const json = JSON.parse(nextData.textContent);
        const findTerms = (obj) => {
          if (!obj || typeof obj !== 'object') return;
          if (Array.isArray(obj)) { obj.forEach(findTerms); return; }
          if (obj.word && obj.definition && typeof obj.word === 'string') {
            dict[obj.word.trim()] = obj.definition.trim();
          }
          if (obj.term && obj.definition && typeof obj.term === 'string') {
            dict[obj.term.trim()] = obj.definition.trim();
          }
          Object.values(obj).forEach(findTerms);
        };
        findTerms(json);
      }
    } catch(e) { /* ignore */ }
  }

  console.log('[QuizletBot] Mots détectés :', Object.keys(dict).length, dict);
  return dict;
}

async function runMatchBot(wordsDefsDict, speed, loadDelay) {
  // Vitesse par défaut = Normal si non fournie
  if (!speed) speed = { move: 15, hover: 40, hold: 60, between: 200, pair: 300 };
  if (loadDelay === undefined) loadDelay = 800;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const normalize = s => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

  // Notifier le popup que le bot démarre
  chrome.runtime.sendMessage({ action: 'botStatus', status: 'running' });

  // 1. Aller sur /match si pas déjà dessus
  if (!location.href.includes('/match')) {
    const matchUrl = location.href.replace(/\/$/, '') + '/match';
    location.href = matchUrl;
    return; // la page va se recharger, le bot sera relancé après redirection
  }

  // 2. Attendre les tuiles
  const waitFor = (cond, timeout = 8000, interval = 100) => new Promise((res, rej) => {
    const start = Date.now();
    (function check() {
      try {
        if (cond()) return res();
        if (Date.now() - start > timeout) return rej('timeout');
        setTimeout(check, interval);
      } catch (e) { rej(e); }
    })();
  });

  try {
    // Cliquer sur "Démarrer" si présent
    await waitFor(() => document.querySelectorAll('button').length > 0, 5000).catch(() => {});
    const startBtn = Array.from(document.querySelectorAll('button'))
      .find(b => /commencer|démarrer|start|jouer|play|go|weiter/i.test(b.innerText || ''));
    if (startBtn) { startBtn.click(); await sleep(loadDelay); }

    // Attendre les tuiles : div.t1s3w3lt contenant div[aria-label].FormattedText
    await waitFor(() => document.querySelectorAll('div.t1s3w3lt').length >= 4, 8000);
    await sleep(loadDelay);

    // Construire l'index des tuiles par texte normalisé
    // Chaque tuile = div.t1s3w3lt > div[aria-label].FormattedText
    const getTiles = () => Array.from(document.querySelectorAll('div.t1s3w3lt'))
      .filter(el => el.querySelector('.FormattedText'));

    const normMap = {};
    getTiles().forEach(tile => {
      const inner = tile.querySelector('.FormattedText');
      const label = (inner?.getAttribute('aria-label') || inner?.textContent || '').trim();
      const n = normalize(label);
      if (!n) return;
      if (!normMap[n]) normMap[n] = [];
      normMap[n].push(tile);
    });

    const findTile = text => {
      const t = normalize(text);
      if (!t) return null;
      // Correspondance exacte
      if (normMap[t]) return normMap[t].find(e => !e.__matched) || null;
      // Correspondance partielle (gère virgules, parenthèses)
      for (const key in normMap) {
        if (key.includes(t) || t.includes(key)) {
          return normMap[key].find(e => !e.__matched) || null;
        }
      }
      return null;
    };

    // Position courante simulée de la souris (part du centre de l'écran)
    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;

    // Variation aléatoire humaine : légèrement à côté du centre de la tuile
    const jitter = (range) => (Math.random() - 0.5) * 2 * range;
    const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

    // Déplacer la souris en plusieurs étapes (simulation trajectoire)
    const moveMouse = async (targetX, targetY, stepDelay) => {
      const steps = stepDelay > 0 ? randInt(6, 12) : 1;
      for (let i = 1; i <= steps; i++) {
        const progress = i / steps;
        // Courbe légèrement courbée (easing + bruit)
        const ease = progress < 0.5 ? 2 * progress * progress : -1 + (4 - 2 * progress) * progress;
        const nx = mouseX + (targetX - mouseX) * ease + jitter(4);
        const ny = mouseY + (targetY - mouseY) * ease + jitter(4);
        const moveOpts = { bubbles: true, cancelable: true, clientX: nx, clientY: ny };
        document.dispatchEvent(new MouseEvent('mousemove', moveOpts));
        if (stepDelay > 0) await sleep(randInt(stepDelay * 0.5, stepDelay * 2) | 0);
      }
      mouseX = targetX;
      mouseY = targetY;
    };

    const clickTile = async el => {
      if (!el) return;
      const rect = el.getBoundingClientRect();
      // Cliquer légèrement à côté du centre (pas exactement au pixel près)
      const cx = rect.left + rect.width  * (0.35 + Math.random() * 0.3);
      const cy = rect.top  + rect.height * (0.35 + Math.random() * 0.3);

      // 1. Déplacer la souris vers la tuile
      await moveMouse(cx, cy, speed.move);
      await sleep(randInt(speed.hover * 0.5, speed.hover * 1.5) | 0);

      // 2. Survol
      const hoverOpts = { bubbles: true, cancelable: true, clientX: cx, clientY: cy };
      el.dispatchEvent(new PointerEvent('pointerover', hoverOpts));
      el.dispatchEvent(new MouseEvent('mouseover', hoverOpts));
      el.dispatchEvent(new MouseEvent('mousemove', hoverOpts));
      await sleep(randInt(speed.hover * 0.3, speed.hover * 0.8) | 0);

      // 3. Appui
      const downOpts = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, button: 0, buttons: 1 };
      el.dispatchEvent(new PointerEvent('pointerdown', downOpts));
      el.dispatchEvent(new MouseEvent('mousedown', downOpts));
      await sleep(randInt(speed.hold * 0.5, speed.hold * 1.5) | 0);

      // 4. Relâchement + clic
      const upOpts = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, button: 0 };
      el.dispatchEvent(new PointerEvent('pointerup', upOpts));
      el.dispatchEvent(new MouseEvent('mouseup', upOpts));
      el.dispatchEvent(new MouseEvent('click', upOpts));
    };

    let matched = 0;
    for (const [key, val] of Object.entries(wordsDefsDict)) {
      let kEl = findTile(key);
      let vEl = findTile(val);

      // Fallback : tronquer après virgule/parenthèse
      if (!kEl || !vEl) {
        const sk = key.split(/[,(]/)[0].trim();
        const sv = val.split(/[,(]/)[0].trim();
        kEl = kEl || findTile(sk);
        vEl = vEl || findTile(sv);
      }

      if (kEl && vEl && kEl !== vEl && !kEl.__matched && !vEl.__matched) {
        await clickTile(kEl);
        await sleep(randInt(speed.between * 0.5, speed.between * 1.5) | 0);
        await clickTile(vEl);
        kEl.__matched = true;
        vEl.__matched = true;
        matched++;
        await sleep(randInt(speed.pair * 0.5, speed.pair * 1.5) | 0);
      }
    }

    chrome.runtime.sendMessage({ action: 'botStatus', status: 'done', matched });
  } catch (err) {
    chrome.runtime.sendMessage({ action: 'botStatus', status: 'error', error: err.toString() });
  }
}
